package Question1;

@SuppressWarnings("unused")
public class Main {
    public static void main(String[] args) {
        Mobile mobile = new Mobile("Galaxy","Samsung");
    }
}
