public class Main{

    @SuppressWarnings("unused")
    public static void main(String[] args) {

        //object of the startingPage class
        StartingPage startingPage = new StartingPage();
    }
}