package Users;
public abstract class SystemUser {
    public abstract void login();
    public abstract void logout();
}
